package gq.kirmanak.mealient.data.baseurl

data class VersionInfo(
    val version: String,
)