package gq.kirmanak.mealient.data.baseurl

enum class ServerVersion { V0, V1 }