package gq.kirmanak.mealient.data.share

data class ParseRecipeURLInfo(
    val url: String,
    val includeTags: Boolean
)
