package gq.kirmanak.mealient.logging

enum class LogLevel { VERBOSE, DEBUG, INFO, WARNING, ERROR }