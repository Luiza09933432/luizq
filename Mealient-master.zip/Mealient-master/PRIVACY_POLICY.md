## Mealient: Privacy policy

Welcome to the Mealient app for Android!

This is an open source Android app developed by Kirill Kamakin. The source code is available on
GitHub under the MIT license; the app is also available on Google Play.

I hereby state, to the best of my knowledge and belief, that I have not programmed this app to
collect any personally identifiable information. All data created by the you (the user) is stored on
the Mealie server(s) that you connect to. It can be removed by the administrator(s) of this (these)
server(s).

Yours sincerely,  
Kirill Kamakin.  
Stockholm, Sweden
mealient@gmail.com